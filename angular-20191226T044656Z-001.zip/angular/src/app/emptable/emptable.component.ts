import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { EmployeeModule } from '../employee/employee.module';

@Component({
  selector: 'app-emptable',
  templateUrl: './emptable.component.html',
  styleUrls: ['./emptable.component.css']
})
export class EmptableComponent implements OnInit {

  constructor(private employeeService : EmployeeService) { }

  ngOnInit() {
    this.getAllEmployee();
  }
  getAllEmployee()
  {
    this.employeeService.getAllEmployee();
  }

  deleteEmployee(id:number)
  {
    console.log(id);
    this.employeeService.deleteEmployee(id).subscribe((data)=>{
        this.getAllEmployee();
    });
  }

  editEmployee(employee:EmployeeModule)
  {
    console.log(employee.id);
    this.employeeService.currentEmployee = Object.assign({},employee);
    }
  }
/*

  editEmployee(employee: Employee) {
    this.employeeService.currentEmployee = Object.assign({}, employee);
  }
*/
