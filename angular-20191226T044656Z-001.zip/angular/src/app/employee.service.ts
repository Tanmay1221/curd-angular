import { Injectable } from '@angular/core';
import { EmployeeModule } from './employee/employee.module';
import { HttpClient ,HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';

const headeroption={
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
}
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  mockurl='http://localhost:3000/Employee';
  allEmployee:EmployeeModule[];
  currentEmployee: EmployeeModule = {
    id: null,
    FirstName: '',
    LastName: ''
  }
  constructor(private http: HttpClient) { }
//get all employee
getAllEmployee()
{
  return this.http.get(this.mockurl).subscribe((data:EmployeeModule[])=>{
    this.allEmployee=data;
  });
}

//add create new employee
createEmployee(employee:EmployeeModule):Observable<EmployeeModule>{
  return this.http.post<EmployeeModule>(this.mockurl,employee,headeroption);
}

//delete employee
deleteEmployee(id:number):Observable<EmployeeModule>{
  return this.http.delete<EmployeeModule>(this.mockurl+'/'+id,headeroption);
}

//edit employee
editEmployee(employee:EmployeeModule):Observable<EmployeeModule>{
  return this.http.put<EmployeeModule>(this.mockurl+'/'+employee.id,employee,headeroption);
}
}
/*
updateEmployee(employee: Employee): Observable<Employee> {
    return this.http.put<Employee>(this.mockUrl + '/' + employee.id, employee, headerOption);
  }
*/
