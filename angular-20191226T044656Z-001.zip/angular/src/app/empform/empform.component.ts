import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { EmployeeModule } from '../employee/employee.module';

@Component({
  selector: 'app-empform',
  templateUrl: './empform.component.html',
  styleUrls: ['./empform.component.css']
})
export class EmpformComponent implements OnInit {

  constructor(private employeeService:EmployeeService) { }

  ngOnInit() {
  }

  createEmployee(currentEmployee:EmployeeModule)
  {
    console.log(currentEmployee.id);
    if(currentEmployee.id===null)
    {
      console.log("in createEmployee");
      this.employeeService.createEmployee(currentEmployee).subscribe((data)=>{
        this.employeeService.getAllEmployee();
      });
    }
    else{
      this.employeeService.editEmployee(currentEmployee).subscribe((data)=>{
        this.employeeService.getAllEmployee();
      })
    }
  }

}
